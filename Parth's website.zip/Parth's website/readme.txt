Parth Shelgaonkar's webpage

parthshel.com | @parth_shel

main content editing in index.html

background and other style editing in "\assets\css\main.css"

note: to change background, look for "background:" in main.css